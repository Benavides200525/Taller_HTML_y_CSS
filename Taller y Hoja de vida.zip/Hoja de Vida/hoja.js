// Función para cambiar el color de fondo del encabezado cuando se hace scroll
window.addEventListener('scroll', function() {
    var header = document.querySelector('header');
    header.classList.toggle('sticky', window.scrollY > 0);
  });
  
  // Función para abrir y cerrar la barra de navegación en dispositivos móviles
  function toggleMenu() {
    var menu = document.querySelector('.menu');
    menu.classList.toggle('active');
  }